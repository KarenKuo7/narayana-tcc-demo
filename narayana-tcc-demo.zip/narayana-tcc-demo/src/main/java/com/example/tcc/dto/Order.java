package com.example.tcc.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Order {

    @JsonProperty("OrderId")
    private String orderId;

    @JsonProperty("Item")
    private String item;

    @JsonProperty("Quantity")
    private int quantity;

    @JsonProperty("Price")
    private BigDecimal price;

    public void setCreateTime(LocalDateTime now) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setCreateTime'");
    }

}
