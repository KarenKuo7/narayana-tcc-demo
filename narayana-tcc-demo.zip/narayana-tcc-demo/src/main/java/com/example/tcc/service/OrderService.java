package com.example.tcc.service;

import com.example.tcc.dto.Order;
import com.example.tcc.entity.OrderEntity;
import com.example.tcc.repository.OrderRepository;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;

import org.eclipse.microprofile.lra.annotation.Compensate;
import org.eclipse.microprofile.lra.annotation.Complete;
import org.eclipse.microprofile.lra.annotation.ws.rs.LRA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;

import java.net.URI;
import java.time.LocalDateTime;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private InventoryService inventoryService;

    // @Autowired
    // private LRAClient lraClient;

    @Transactional
    @LRA(value = LRA.Type.REQUIRED)
    public void createOrder(URI lraId, Order order) {
        // Narayana LRA 協調器使用URI來標識LRA
        // 這裡的lraId是從請求標頭中獲取的LRA ID
        // 在實際應用中，您可能需要使用LRAClient來創建LRA
        // URI lraUri = lraClient.startLRA();
        // 這裡的lraId是從請求標頭中獲取的LRA ID
        // URI lraUri = URI.create(lraId);
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setOrderId(lraId.toString());
        orderEntity.setItem(order.getItem());
        orderEntity.setQuantity(order.getQuantity());
        orderEntity.setPrice(order.getPrice());
        orderEntity.setStatus("PENDING");
        orderEntity.setCreateTime(LocalDateTime.now());
        orderRepository.save(orderEntity);
        inventoryService.deductStock(lraId, order.getItem(), order.getQuantity());
    }

    // LRA-ID 協調辨識唯一標識符
    @Complete
    @PUT
    // @Path("/complete")
    public String confirm(@RequestHeader("LRA-Id") URI lraId) {
        // OrderEntity orderEntity = orderRepository.findById(lraId)
        // .orElseThrow(() -> new RuntimeException("Order not found: " + lraId));

        // orderEntity.setStatus("CONFIRMED");
        // orderEntity.setUpdateTime(LocalDateTime.now());
        // orderRepository.save(orderEntity);
        // System.out.println("Confirming LRA: " + lraId);
        return "LRA confirmed";
        // 您可以在這裡添加更多的業務邏輯，例如更新訂單狀態
    }

    @Compensate
    @PUT
    // @Path("/compensate")
    public Response cancel(@RequestHeader("LRA-Id") URI lraId) {
        // OrderEntity orderEntity = orderRepository.findById(lraId)
        // .orElseThrow(() -> new RuntimeException("Order not found: " + lraId));
        // orderEntity.setStatus("CANCELLED");
        // orderRepository.save(orderEntity);
        System.out.println("Cancelling LRA: " + lraId);

        return Response.ok("LRA confirmed: " + lraId).build();
    }

}