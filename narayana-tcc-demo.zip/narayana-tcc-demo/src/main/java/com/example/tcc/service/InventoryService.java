package com.example.tcc.service;

import com.example.tcc.dto.Order;
import com.example.tcc.entity.InventoryEntity;
import com.example.tcc.repository.InventoryRepository;
import jakarta.transaction.Transactional;

import java.net.URI;

import org.eclipse.microprofile.lra.annotation.*;
import org.eclipse.microprofile.lra.annotation.ws.rs.LRA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;

@Service
public class InventoryService {
    @Autowired
    private InventoryRepository inventoryRepository;

    @LRA(value = LRA.Type.REQUIRED)
    @Transactional
    public void deductStock(URI lraId, String item, int quantity) {
        InventoryEntity inventory = inventoryRepository.findByItem(item);
        if (inventory.getStock() < quantity) {
            throw new RuntimeException("庫存不足");
        }
        inventory.setStock(inventory.getStock() - quantity);
        inventoryRepository.save(inventory);
    }

    @Complete
    public void confirm(@RequestHeader("LRA-Id") URI lraId) {
        System.out.println("庫存交易確認: " + lraId);
    }

    @Compensate
    public void cancel(@RequestHeader("LRA-Id") URI lraId) {
        System.out.println("庫存交易回滾: " + lraId);
        // 補回庫存行為僅在示範中進行，實際應儲存扣除暫存資料
    }
}