package com.example.tcc.controller;

import java.net.URI;

import org.eclipse.microprofile.lra.annotation.Compensate;
import org.eclipse.microprofile.lra.annotation.Complete;
import org.eclipse.microprofile.lra.annotation.ws.rs.LRA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.tcc.dto.Order;
import com.example.tcc.service.InventoryService;
import com.example.tcc.service.OrderService;

@RestController
@RequestMapping("/orders")
public class CreateController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private InventoryService inventoryService;

    @LRA(value = LRA.Type.REQUIRED, end = false)
    @PostMapping("/create")
    public String createOrder(@RequestBody Order order,
            @RequestHeader(LRA.LRA_HTTP_CONTEXT_HEADER) URI lraId) {
        try {
            // 這裡的lraId是從請求標頭中獲取的LRA ID
            // 在實際應用中，您可能需要使用LRAClient來創建LRA
            // URI lraUri = lraClient.startLRA();
            System.out.println("Create order under LRA: " + lraId);
            orderService.createOrder(lraId, order);
            inventoryService.deductStock(lraId, order.getItem(), order.getQuantity());
            return "Created under LRA " + lraId;
        } catch (Exception e) {

            return " LRA error";
        }
    }

    // 2️⃣ Confirm 階段：Coordinator close 時呼叫
    @PutMapping("/complete")
    @Complete
    public String confirm(@RequestHeader("LRA-Context") URI lraId) {
        orderService.confirm(lraId);
        inventoryService.confirm(lraId);
        return "Confirmed " + lraId;
    }

    // 3️⃣ Compensate 階段：Coordinator cancel 時呼叫
    @PutMapping("/compensate")
    @Compensate
    public String compensate(@RequestHeader("LRA-Context") URI lraId) {
        inventoryService.cancel(lraId);
        orderService.cancel(lraId);
        return "Compensated " + lraId;
    }
}
