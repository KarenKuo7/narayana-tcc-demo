-- 訂單表：order_table
CREATE TABLE orders (
    order_id VARCHAR(64) PRIMARY KEY,
    item VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 庫存表：inventory
CREATE TABLE inventory (
    item VARCHAR(64) PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    stock INT NOT NULL,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
-- 初始化庫存數據
insert into inventory (item, item_name, stock) values (1,'item1', 10);
insert into inventory (item, item_name, stock) values (2,'item2', 20);
insert into inventory (item, item_name, stock) values (3,'item3', 30);


-- 付款表：payment
CREATE TABLE payment (
    order_id VARCHAR(64) PRIMARY KEY,
    price DECIMAL(10, 2) NOT NULL,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 記錄表：log_table
CREATE TABLE log_table (
    order_id VARCHAR(64),
    item VARCHAR(100),
    price DECIMAL(10, 2),
    success CHAR(1) CHECK (success IN ('Y', 'N'))
);